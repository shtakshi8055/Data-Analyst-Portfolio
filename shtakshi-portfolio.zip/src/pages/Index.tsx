import { Link } from "react-router-dom";
import { ArrowRight, Database, Brain, BarChart3, Code2, TrendingUp, Sparkles } from "lucide-react";
import ParticleField from "@/components/ParticleField";
import TypeWriter from "@/components/TypeWriter";
import AnimatedCounter from "@/components/AnimatedCounter";

const stats = [
  { label: "Projects Completed", value: 10, suffix: "+" },
  { label: "Months Experience", value: 6, suffix: "+" },
  { label: "Tools & Technologies", value: 15, suffix: "+" },
  { label: "Records Analyzed", value: 8, suffix: "K+" },
];

const highlights = [
  { icon: Database, title: "SQL & Databases", desc: "Advanced queries with joins, CTEs, window functions, and query optimization" },
  { icon: Brain, title: "Machine Learning", desc: "Regression, classification, and predictive modeling with Scikit-learn" },
  { icon: BarChart3, title: "Data Visualization", desc: "Interactive dashboards and KPI reporting with Power BI & Excel" },
  { icon: TrendingUp, title: "Data Analysis", desc: "EDA, statistical analysis, data cleaning, and ETL pipelines" },
];

const Index = () => (
  <div className="min-h-screen">
    {/* Hero */}
    <section className="relative min-h-screen flex items-center data-grid overflow-hidden">
      <ParticleField />
      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-3xl section-fade-in">
          <div className="flex items-center gap-2 mb-6">
            <div className="h-px w-12 bg-primary" />
            <span className="text-xs font-mono uppercase tracking-[0.2em] text-primary">
              Welcome to my portfolio
            </span>
          </div>

          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold leading-tight mb-4">
            <span className="text-foreground">Hi, I'm </span>
            <span className="gradient-text">Shtakshi Sharma</span>
          </h1>

          <h2 className="text-2xl md:text-3xl font-semibold text-muted-foreground mb-2">
            <TypeWriter texts={["Data Analyst", "Data Scientist", "Python Developer", "BI Developer"]} />
          </h2>

          <p className="text-lg text-muted-foreground max-w-xl mb-8 leading-relaxed section-fade-in stagger-2">
            Transforming raw datasets into actionable business insights using Python, SQL, Excel, and Power BI. Passionate about data accuracy, reporting automation, and decision-support analytics.
          </p>

          <div className="flex flex-wrap gap-4 section-fade-in stagger-3">
            <Link
              to="/projects"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-lg font-medium text-sm text-primary-foreground transition-all duration-300 hover:scale-105"
              style={{ backgroundImage: "var(--gradient-primary)" }}
            >
              View Projects <ArrowRight className="w-4 h-4" />
            </Link>
            <Link
              to="/contact"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-lg font-medium text-sm text-foreground border border-border hover:border-primary/50 hover:bg-primary/5 transition-all duration-300"
            >
              Get in Touch
            </Link>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-muted-foreground">
        <span className="text-[10px] font-mono uppercase tracking-widest">Scroll</span>
        <div className="w-px h-8 bg-gradient-to-b from-primary/50 to-transparent" />
      </div>
    </section>

    {/* Stats */}
    <section className="py-20 border-y border-border/50">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((stat) => (
            <div key={stat.label} className="text-center">
              <div className="text-3xl md:text-4xl mb-2">
                <AnimatedCounter end={stat.value} suffix={stat.suffix} />
              </div>
              <p className="text-xs font-mono uppercase tracking-wider text-muted-foreground">
                {stat.label}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>

    {/* Highlights */}
    <section className="py-24">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 mb-4">
            <Sparkles className="w-4 h-4 text-primary" />
            <span className="text-xs font-mono uppercase tracking-[0.2em] text-primary">
              What I Do
            </span>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground">
            Core <span className="gradient-text">Expertise</span>
          </h2>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {highlights.map((item, i) => (
            <div
              key={item.title}
              className={`card-gradient rounded-xl border border-border/50 p-6 hover-lift section-fade-in stagger-${i + 1}`}
            >
              <div className="w-10 h-10 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center mb-4">
                <item.icon className="w-5 h-5 text-primary" />
              </div>
              <h3 className="font-semibold text-foreground mb-2">{item.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>

    {/* CTA */}
    <section className="py-24 data-grid relative">
      <div className="container mx-auto px-6 text-center relative z-10">
        <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
          Let's <span className="gradient-accent-text">Collaborate</span>
        </h2>
        <p className="text-muted-foreground mb-8 max-w-md mx-auto">
          Have a data challenge? I'd love to help turn your data into decisions.
        </p>
        <Link
          to="/contact"
          className="inline-flex items-center gap-2 px-8 py-3 rounded-lg font-medium text-sm text-primary-foreground transition-all duration-300 hover:scale-105"
          style={{ backgroundImage: "var(--gradient-primary)" }}
        >
          Start a Conversation <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    </section>
  </div>
);

export default Index;
