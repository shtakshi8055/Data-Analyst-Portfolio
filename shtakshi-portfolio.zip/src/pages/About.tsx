import { Briefcase, GraduationCap, Award, MapPin, Calendar, Download } from "lucide-react";
import AnimatedCounter from "@/components/AnimatedCounter";

const timeline = [
  {
    year: "Jan 2026 – Apr 2026",
    title: "Data Analyst Intern",
    company: "Ziion Technology, Mohali",
    description: "Conducted EDA on diverse datasets, developed automated analytical workflows using Python & SQL, wrote advanced SQL queries, and built basic ML models for predictive analytics.",
    type: "work",
  },
  {
    year: "Aug 2022 – May 2026",
    title: "B.Tech Computer Science Engineering",
    company: "Chandigarh Engineering College, Landran",
    description: "CGPA: 8.01 — Foundation in algorithms, databases, software engineering, and data science with hands-on project experience.",
    type: "education",
  },
];

const certifications = [
  "Python for Data Science",
  "SQL Advanced Queries",
  "Power BI Dashboard Development",
  "Machine Learning Fundamentals",
];

const About = () => (
  <div className="min-h-screen pt-24">
    {/* Header */}
    <section className="py-16">
      <div className="container mx-auto px-6">
        <div className="max-w-3xl section-fade-in">
          <div className="flex items-center gap-2 mb-6">
            <div className="h-px w-12 bg-primary" />
            <span className="text-xs font-mono uppercase tracking-[0.2em] text-primary">About Me</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold mb-6">
            Passionate about turning <span className="gradient-text">data into impact</span>
          </h1>
          <p className="text-lg text-muted-foreground leading-relaxed mb-4">
            I'm Shtakshi Sharma, a Data Analyst with hands-on experience in data cleaning, exploratory analysis, dashboard development, and automated analytics workflows. I specialize in transforming raw datasets into actionable business insights using Python, SQL, Excel, and Power BI.
          </p>
          <p className="text-muted-foreground leading-relaxed">
            Experienced in ETL processes, KPI reporting, and predictive modeling with basic machine learning techniques. I have a strong focus on data accuracy, reporting automation, and decision-support analytics.
          </p>
        </div>
      </div>
    </section>

    {/* Timeline */}
    <section className="py-16">
      <div className="container mx-auto px-6">
        <h2 className="text-2xl font-bold text-foreground mb-12 flex items-center gap-3">
          <Briefcase className="w-5 h-5 text-primary" />
          Experience & Education
        </h2>
        <div className="relative">
          <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-px bg-border" />
          <div className="space-y-12">
            {timeline.map((item, i) => (
              <div
                key={i}
                className={`relative flex flex-col md:flex-row gap-6 section-fade-in stagger-${(i % 5) + 1} ${
                  i % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"
                }`}
              >
                <div className="md:w-1/2 md:text-right md:pr-12 pl-12 md:pl-0">
                  {i % 2 === 0 ? (
                    <TimelineContent item={item} />
                  ) : (
                    <div className="hidden md:block" />
                  )}
                  {i % 2 !== 0 && <div className="md:hidden"><TimelineContent item={item} /></div>}
                </div>
                {/* Dot */}
                <div className="absolute left-4 md:left-1/2 -translate-x-1/2 w-3 h-3 rounded-full bg-primary border-2 border-background mt-2" />
                <div className="md:w-1/2 md:pl-12">
                  {i % 2 !== 0 ? (
                    <div className="hidden md:block"><TimelineContent item={item} align="left" /></div>
                  ) : null}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>

    {/* Certifications */}
    <section className="py-16 border-t border-border/50">
      <div className="container mx-auto px-6">
        <h2 className="text-2xl font-bold text-foreground mb-8 flex items-center gap-3">
          <Award className="w-5 h-5 text-primary" />
          Key Strengths
        </h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {certifications.map((cert) => (
            <div
              key={cert}
              className="card-gradient rounded-xl border border-border/50 p-5 hover-lift flex items-start gap-3"
            >
              <Award className="w-4 h-4 text-accent mt-0.5 flex-shrink-0" />
              <span className="text-sm font-medium text-foreground">{cert}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  </div>
);

const TimelineContent = ({ item, align = "right" }: { item: typeof timeline[0]; align?: string }) => (
  <div className={`card-gradient rounded-xl border border-border/50 p-5 hover-lift ${align === "left" ? "text-left" : ""}`}>
    <div className="flex items-center gap-2 mb-2">
      {item.type === "work" ? (
        <Briefcase className="w-3 h-3 text-primary" />
      ) : (
        <GraduationCap className="w-3 h-3 text-secondary" />
      )}
      <span className="text-[10px] font-mono uppercase tracking-wider text-primary">{item.year}</span>
    </div>
    <h3 className="font-semibold text-foreground mb-1">{item.title}</h3>
    <p className="text-sm text-primary/80 mb-2">{item.company}</p>
    <p className="text-sm text-muted-foreground leading-relaxed">{item.description}</p>
  </div>
);

export default About;
