import { useState } from "react";
import ProjectCard from "@/components/ProjectCard";
import { Filter } from "lucide-react";

const projects = [
  {
    title: "Netflix Dataset Analysis",
    description: "Performed EDA on 8,800+ Netflix records using Python. Built a Power BI dashboard to visualize content trends and KPIs, generating insights for data-driven decision-making.",
    tags: ["Python", "Pandas", "Seaborn", "Power BI"],
    category: "Data Analytics",
    github: "#",
    live: "#",
  },
  {
    title: "Sales Dashboard Analysis",
    description: "Developed an interactive Power BI dashboard tracking 15+ KPIs, resulting in a 10% increase in regional sales visibility. Analyzed data across regions, products, and time periods.",
    tags: ["Power BI", "Excel", "DAX", "Data Modeling"],
    category: "Data Analytics",
    github: "#",
  },
  {
    title: "Customer Churn Prediction",
    description: "Built a classification model using Scikit-learn to predict customer churn, applying feature engineering and data preprocessing techniques for improved accuracy.",
    tags: ["Python", "Scikit-learn", "Pandas", "ML"],
    category: "Machine Learning",
    github: "#",
  },
  {
    title: "ETL Pipeline Automation",
    description: "Designed and automated analytical workflows using Python and SQL, enabling efficient data extraction, transformation, and loading processes for regular business reporting.",
    tags: ["Python", "SQL", "ETL", "Automation"],
    category: "Data Engineering",
    github: "#",
  },
  {
    title: "SQL Data Analysis Project",
    description: "Wrote advanced SQL queries using joins, aggregations, subqueries, and window functions to extract business insights from complex relational databases.",
    tags: ["MySQL", "SQL", "CTEs", "Window Functions"],
    category: "Data Analytics",
    github: "#",
  },
  {
    title: "Regression & Classification Models",
    description: "Preprocessed data and performed feature engineering to train and evaluate supervised ML models including regression and classification algorithms.",
    tags: ["Python", "Scikit-learn", "Pandas", "NumPy"],
    category: "Machine Learning",
    github: "#",
  },
];

const categories = ["All", "Data Analytics", "Machine Learning", "Data Engineering"];

const Projects = () => {
  const [active, setActive] = useState("All");
  const filtered = active === "All" ? projects : projects.filter((p) => p.category === active);

  return (
    <div className="min-h-screen pt-24">
      <section className="py-16">
        <div className="container mx-auto px-6">
          <div className="max-w-2xl mb-12 section-fade-in">
            <div className="flex items-center gap-2 mb-6">
              <div className="h-px w-12 bg-primary" />
              <span className="text-xs font-mono uppercase tracking-[0.2em] text-primary">Portfolio</span>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Featured <span className="gradient-text">Projects</span>
            </h1>
            <p className="text-muted-foreground leading-relaxed">
              A selection of data analysis, visualization, and machine learning projects showcasing end-to-end problem solving.
            </p>
          </div>

          {/* Filters */}
          <div className="flex items-center gap-2 mb-10 flex-wrap">
            <Filter className="w-4 h-4 text-muted-foreground" />
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActive(cat)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                  active === cat
                    ? "bg-primary/10 text-primary border border-primary/30"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted border border-transparent"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map((project, i) => (
              <div key={project.title} className={`section-fade-in stagger-${(i % 5) + 1}`}>
                <ProjectCard {...project} />
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Projects;
