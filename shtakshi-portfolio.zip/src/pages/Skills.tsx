import SkillBar from "@/components/SkillBar";
import { Code2, Database, BarChart3, Brain, Wrench } from "lucide-react";

const skillGroups = [
  {
    icon: Code2,
    title: "Programming",
    skills: [
      { name: "Python", level: 90 },
      { name: "SQL (MySQL)", level: 88 },
      { name: "Pandas / NumPy", level: 90 },
      { name: "Matplotlib / Seaborn", level: 85 },
    ],
  },
  {
    icon: Database,
    title: "SQL & Databases",
    skills: [
      { name: "Joins & Subqueries", level: 90 },
      { name: "CTEs & Window Functions", level: 85 },
      { name: "Query Optimization", level: 80 },
      { name: "Indexing", level: 78 },
    ],
  },
  {
    icon: BarChart3,
    title: "Data Analysis & BI",
    skills: [
      { name: "Power BI", level: 88 },
      { name: "Excel", level: 90 },
      { name: "EDA & Statistical Analysis", level: 85 },
      { name: "KPI & Stakeholder Reporting", level: 82 },
    ],
  },
  {
    icon: Brain,
    title: "Machine Learning",
    skills: [
      { name: "Scikit-learn", level: 80 },
      { name: "Regression Models", level: 78 },
      { name: "Classification Models", level: 78 },
      { name: "Feature Engineering", level: 75 },
    ],
  },
  {
    icon: Wrench,
    title: "Tools & Platforms",
    skills: [
      { name: "Jupyter Notebook", level: 90 },
      { name: "VS Code", level: 88 },
      { name: "Git", level: 80 },
      { name: "ETL Pipelines", level: 78 },
    ],
  },
];

const Skills = () => (
  <div className="min-h-screen pt-24">
    <section className="py-16">
      <div className="container mx-auto px-6">
        <div className="max-w-2xl mb-16 section-fade-in">
          <div className="flex items-center gap-2 mb-6">
            <div className="h-px w-12 bg-primary" />
            <span className="text-xs font-mono uppercase tracking-[0.2em] text-primary">Expertise</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Technical <span className="gradient-text">Skills</span>
          </h1>
          <p className="text-muted-foreground leading-relaxed">
            A comprehensive overview of my technical toolkit, honed through internship experience and multiple end-to-end projects.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skillGroups.map((group, gi) => (
            <div
              key={group.title}
              className={`card-gradient rounded-xl border border-border/50 p-6 hover-lift section-fade-in stagger-${(gi % 5) + 1}`}
            >
              <div className="flex items-center gap-3 mb-6">
                <div className="w-9 h-9 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center">
                  <group.icon className="w-4 h-4 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground">{group.title}</h3>
              </div>
              <div className="space-y-5">
                {group.skills.map((skill, si) => (
                  <SkillBar key={skill.name} {...skill} delay={si * 150 + gi * 100} />
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  </div>
);

export default Skills;
