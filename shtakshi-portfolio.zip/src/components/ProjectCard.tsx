import { ExternalLink, Github, ArrowUpRight } from "lucide-react";

interface ProjectCardProps {
  title: string;
  description: string;
  tags: string[];
  image?: string;
  github?: string;
  live?: string;
  category: string;
}

const ProjectCard = ({ title, description, tags, category, github, live }: ProjectCardProps) => (
  <div className="group card-gradient rounded-xl border border-border/50 overflow-hidden hover-lift">
    {/* Decorative header bar */}
    <div className="h-1 w-full bg-gradient-to-r from-primary via-secondary to-accent" />
    
    <div className="p-6">
      <div className="flex items-start justify-between mb-3">
        <span className="text-[10px] font-mono uppercase tracking-widest text-primary bg-primary/10 px-2 py-1 rounded">
          {category}
        </span>
        <div className="flex gap-2">
          {github && (
            <a href={github} className="text-muted-foreground hover:text-primary transition-colors">
              <Github className="w-4 h-4" />
            </a>
          )}
          {live && (
            <a href={live} className="text-muted-foreground hover:text-primary transition-colors">
              <ExternalLink className="w-4 h-4" />
            </a>
          )}
        </div>
      </div>

      <h3 className="text-lg font-semibold text-foreground mb-2 group-hover:text-primary transition-colors flex items-center gap-1">
        {title}
        <ArrowUpRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
      </h3>
      <p className="text-sm text-muted-foreground mb-4 leading-relaxed">{description}</p>

      <div className="flex flex-wrap gap-2">
        {tags.map((tag) => (
          <span
            key={tag}
            className="text-[10px] font-mono px-2 py-1 rounded-md bg-muted text-muted-foreground border border-border/50"
          >
            {tag}
          </span>
        ))}
      </div>
    </div>
  </div>
);

export default ProjectCard;
