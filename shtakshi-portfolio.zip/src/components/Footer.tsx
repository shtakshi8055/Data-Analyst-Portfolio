import { BarChart3, Github, Linkedin, Mail } from "lucide-react";
import { Link } from "react-router-dom";

const Footer = () => (
  <footer className="border-t border-border/50 bg-card/30">
    <div className="container mx-auto px-6 py-8">
      <div className="flex flex-col md:flex-row items-center justify-between gap-4">
        <Link to="/" className="flex items-center gap-2">
          <BarChart3 className="w-4 h-4 text-primary" />
          <span className="font-mono text-sm text-muted-foreground">
            shtakshi<span className="text-primary">.</span>sharma
          </span>
        </Link>
        <div className="flex items-center gap-4">
          <a href="https://github.com/shtakshi8055" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary transition-colors">
            <Github className="w-4 h-4" />
          </a>
          <a href="https://www.linkedin.com/in/shtakshi-sharma-773805278/" target="_blank" rel="noopener noreferrer" className="text-muted-foreground hover:text-primary transition-colors">
            <Linkedin className="w-4 h-4" />
          </a>
          <a href="mailto:shtakshisharma@gmail.com" className="text-muted-foreground hover:text-primary transition-colors">
            <Mail className="w-4 h-4" />
          </a>
        </div>
        <p className="text-xs text-muted-foreground">
          © 2026 All rights reserved
        </p>
      </div>
    </div>
  </footer>
);

export default Footer;
